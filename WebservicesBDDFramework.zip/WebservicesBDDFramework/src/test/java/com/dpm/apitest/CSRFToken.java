package com.dpm.apitest;


import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.ValidatableResponse;


public class CSRFToken {
	
	public static String sessionid ="BED3F41F8F2488E1102DB396967D6D46" ;
	
	
	@BeforeMethod
	public void HandleSSLCeritificate()
	{
		
		try 
		{
	        RestAssured.port = 8080;
	        RestAssured.useRelaxedHTTPSValidation();
	        RestAssured.config().getSSLConfig().with().keyStore("classpath:keystore.p12", "password");
	    } 
		
		catch (Exception ex) 
		{
	        System.out.println("Error while loading keystore >>>>>>>>>");
	        ex.printStackTrace();
	    }
		
	}
	
	
	@Test(priority=1)
	public void Generate_CSRF_Token()
	{		
		
		RestAssured.baseURI ="https://vdevpril56plp.dsone.3ds.com:443/3DSpace/resources/v1/application/CSRF";
		String response1 = RestAssured.given().cookie("JSESSIONID", "9B5391C4A6CB9C3806C306AAC7EB8C7D").auth().basic("devleader1", "Passport1").when().get().then().extract().asString();
		ValidatableResponse res = RestAssured.given().cookie("JSESSIONID","9B5391C4A6CB9C3806C306AAC7EB8C7D").auth().basic("devleader1", "Passport1").when().get().then();
		res.statusCode(200);
		res.contentType(ContentType.JSON);
		System.out.println("Response output is =  : " + response1);
	    JsonPath js = new JsonPath(response1);
		String csrftoken = js.get("csrf.value");
		System.out.println("CSRF Token = " + csrftoken);
		
	}
	
	
	@Test(priority=2)
	public void Get_ProjectList() throws ParseException
	{
		
		RestAssured.baseURI ="https://vdevpril56plp.dsone.3ds.com/3DSpace/resources/v1/modeler/projects";
		
		String response2 = RestAssured.given().queryParam("include","none,subscriptions").queryParam("fields","none.name").and().header("SecurityContext","ctx::VPLMProjectLeader.MyCompany.dev").header("ENO_CSRF_TOKEN","HKGP-DKQP-1B4S-LQLG-PZ41-DCWS-1ONR-VHRZ").and().header("Content-Type","application/json")
				.cookie("JSESSIONID","9B5391C4A6CB9C3806C306AAC7EB8C7D").auth().basic("devleader1", "Passport1")
				.when().get().then().statusCode(200).extract().asString();
		
	 	System.out.println("Project List =  : " + response2);
	    JsonPath js2 = new JsonPath(response2);
		String data2 = js2.get("data[1].dataelements.title");
	    System.out.println("Project Name = " + data2);
		
		
	    JSONParser parse = new JSONParser();
		//Type caste the parsed json data in json object
		JSONObject jobj = (JSONObject)parse.parse(response2);
		
		JSONArray jsonarr_1 = (JSONArray) jobj.get("data");
		
		for(int i=0;i<jsonarr_1.size();i++)
		{
			//Store the JSON objects in an array
			//Get the index of the JSON object and print the values as per the index
			JSONObject jsonobj_1 = (JSONObject)jsonarr_1.get(i);
			//Store the JSON object in JSON array as objects (For level 2 array element i.e Address Components)
			JSONArray jsonarr_2 = (JSONArray) jsonobj_1.get("dataelements");
			System.out.println("Elements under data array");
			System.out.println("\nPlace id: " +jsonobj_1.get("relId"));
			System.out.println("Types: " +jsonobj_1.get("type"));
		
			System.out.println("Elements under dataelements array");
		
			for(int j=0;j<jsonarr_2.size();j++)
			{
		
				JSONObject jsonobj_2 = (JSONObject) jsonarr_2.get(j);
				//Store the data as String objects
				String str_data1 = (String) jsonobj_2.get("title");
				System.out.println(str_data1);
		
				String str_data2 = (String) jsonobj_2.get("revision");
				System.out.println(str_data2);
		
		 
	         }
	
	
          }
		
	
	  }
}
		
